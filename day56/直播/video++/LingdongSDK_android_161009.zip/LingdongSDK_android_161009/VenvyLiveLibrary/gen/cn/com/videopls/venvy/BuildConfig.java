/** Automatically generated file. DO NOT MODIFY */
package cn.com.videopls.venvy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
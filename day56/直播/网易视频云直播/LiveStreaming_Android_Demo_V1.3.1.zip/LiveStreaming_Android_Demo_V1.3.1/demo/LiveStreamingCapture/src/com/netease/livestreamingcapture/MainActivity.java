package com.netease.livestreamingcapture;


//import com.netease.livestreamingcapture.MediaPreviewActivity;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.netease.LSMediaCapture.util.string.StringUtil;

import java.util.ArrayList;
import java.util.List;

//import com.netease.LSMediaCapture.lsLogUtil;

public class MainActivity extends Activity {
	private OnClickListener OnClickEvent;
	private RadioButton NormalModeBtn;
	private RadioButton BeautyModeBtn;
	private Button mBtnStartBtn;
	private EditText mMediaEditURL;
	private MsgReceiver msgReceiver;
	private String mVideoResolution = "SD";
	private String mFilterMode = "NormalMode";

	private RadioButton mRadioHD;
	private RadioButton mRadioSD;
	private RadioButton mRadioFluency;

	private String mUrlMedia;

	private static final String TAG = "NeteaseLiveStream";
	private static final int REQUEST_CODE = 100;

	//滤镜黑名单：不适用Android滤镜的设备列表
	Blacklist[] g_blacklist = {
	};

	public class Blacklist {
		public Blacklist(String model, int api){
			mModel = model;
			mApi = api;
		}
		public String getModel() {
			return mModel;
		}
		public int getApi() {
			return mApi;
		}
		private String mModel;
		private int mApi;
	}

	public boolean checkCurrentDeviceInBlacklist(){
		boolean bInBlacklist = false;
		String model = Build.MODEL;
		int api = Build.VERSION.SDK_INT;

		int listsize = g_blacklist.length;

		for(int i = 0; i < listsize; i++)
		{
			if(model.equals(g_blacklist[i].getModel()) && api == g_blacklist[i].getApi())
				bInBlacklist = true;
		}

		return bInBlacklist;
	}

	/**   6.0权限处理     **/
	private boolean bPermission = false;
	private final int WRITE_PERMISSION_REQ_CODE = 100;
	private boolean checkPublishPermission() {
		if (Build.VERSION.SDK_INT >= 23) {
			List<String> permissions = new ArrayList<>();
			if (PackageManager.PERMISSION_GRANTED != ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
				permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
			}
			if (PackageManager.PERMISSION_GRANTED != ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)) {
				permissions.add(Manifest.permission.CAMERA);
			}
			if (PackageManager.PERMISSION_GRANTED != ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)) {
				permissions.add(Manifest.permission.RECORD_AUDIO);
			}
			if (PackageManager.PERMISSION_GRANTED != ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_PHONE_STATE)) {
				permissions.add(Manifest.permission.READ_PHONE_STATE);
			}
			if (permissions.size() != 0) {
				ActivityCompat.requestPermissions(MainActivity.this,
						(String[]) permissions.toArray(new String[0]),
						WRITE_PERMISSION_REQ_CODE);
				return false;
			}
		}
		return true;
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		switch (requestCode) {
			case WRITE_PERMISSION_REQ_CODE:
				for (int ret : grantResults) {
					if (ret != PackageManager.PERMISSION_GRANTED) {
						return;
					}
				}
				bPermission = true;
				break;
			default:
				break;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		/**   6.0权限申请     **/
		bPermission = checkPublishPermission();

		setContentView(R.layout.activity_main);

		//动态注册广播接收器，接收Service的消息
		msgReceiver = new MsgReceiver();
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction("LiveStreamingStopFinished");
		registerReceiver(msgReceiver, intentFilter);

		//根据ID找到RadioButton实例
		mRadioHD = (RadioButton) findViewById(R.id.radioHD);
		mRadioSD = (RadioButton) findViewById(R.id.radioSD);
		mRadioFluency = (RadioButton) findViewById(R.id.radioFluency);

		mRadioHD.setButtonDrawable(R.drawable.radio_button_unused);
		mRadioSD.setButtonDrawable(R.drawable.radio_button_used);
		mRadioFluency.setButtonDrawable(R.drawable.radio_button_unused);

		NormalModeBtn = (RadioButton) findViewById(R.id.NormalModeBtn);
		BeautyModeBtn = (RadioButton) findViewById(R.id.BeautyModeBtn);

		NormalModeBtn.setButtonDrawable(R.drawable.radio_button_used);
		BeautyModeBtn.setButtonDrawable(R.drawable.radio_button_unused);

		mBtnStartBtn = (Button) findViewById(R.id.StartAVBtn);
		mBtnStartBtn.setEnabled(true);

		mMediaEditURL = (EditText) findViewById(R.id.RTMP_URL);

		OnClickEvent = new OnClickListener() {

			public void onClick(View v) {
				Intent intent;
				switch (v.getId()) {
					case R.id.radioHD:
						mVideoResolution = "HD";
						mRadioHD.setButtonDrawable(R.drawable.radio_button_used);
						mRadioSD.setButtonDrawable(R.drawable.radio_button_unused);
						mRadioFluency.setButtonDrawable(R.drawable.radio_button_unused);
						mBtnStartBtn.setEnabled(true);
						break;
					case R.id.radioSD:
						mVideoResolution = "SD";
						mRadioHD.setButtonDrawable(R.drawable.radio_button_unused);
						mRadioSD.setButtonDrawable(R.drawable.radio_button_used);
						mRadioFluency.setButtonDrawable(R.drawable.radio_button_unused);
						mBtnStartBtn.setEnabled(true);
						break;
					case R.id.radioFluency:
						mVideoResolution = "Fluency";
						mRadioHD.setButtonDrawable(R.drawable.radio_button_unused);
						mRadioSD.setButtonDrawable(R.drawable.radio_button_unused);
						mRadioFluency.setButtonDrawable(R.drawable.radio_button_used);
						mBtnStartBtn.setEnabled(true);
						break;
					case R.id.NormalModeBtn:
						mFilterMode = "NormalMode";
						NormalModeBtn.setButtonDrawable(R.drawable.radio_button_used);
						BeautyModeBtn.setButtonDrawable(R.drawable.radio_button_unused);
						mBtnStartBtn.setEnabled(true);
						break;
					case R.id.BeautyModeBtn:
						mFilterMode = "BeautyMode";
						NormalModeBtn.setButtonDrawable(R.drawable.radio_button_unused);
						BeautyModeBtn.setButtonDrawable(R.drawable.radio_button_used);
						mBtnStartBtn.setEnabled(true);
						break;
					case R.id.StartAVBtn:
						mUrlMedia = mMediaEditURL.getText().toString();
						intent = new Intent(MainActivity.this, MediaPreviewActivity.class);
						intent.putExtra("mediaPath", mUrlMedia);
						intent.putExtra("videoResolution", mVideoResolution);

						if (mFilterMode.equals("NormalMode")) {
							intent.putExtra("filter", false);
						} else if (mFilterMode.equals("BeautyMode")) {
							intent = new Intent(MainActivity.this, MediaPreviewActivity.class);
							if(checkCurrentDeviceInBlacklist())
							{
								intent.putExtra("mediaPath", mUrlMedia);
								intent.putExtra("videoResolution", mVideoResolution);
								intent.putExtra("filter", false);
							}
							else {
								intent.putExtra("mediaPath", mUrlMedia);
								intent.putExtra("videoResolution", mVideoResolution);
								intent.putExtra("filter", true);
							}
						}
						if(!bPermission){
							Toast.makeText(getApplication(),"请先允许app所需要的权限",Toast.LENGTH_LONG).show();
							bPermission = checkPublishPermission();
							return;
						}

						if(StringUtil.isEmpty(mUrlMedia) || !mUrlMedia.contains(".live.126.net")){
							Toast.makeText(getApplication(),"请先设置正确的推流地址",Toast.LENGTH_LONG).show();
						}else {
							startActivity(intent);
						}
						break;
					default:
						break;
				}
			}
		};

		mRadioHD.setOnClickListener(OnClickEvent);
		mRadioSD.setOnClickListener(OnClickEvent);
		mRadioFluency.setOnClickListener(OnClickEvent);
		NormalModeBtn.setOnClickListener(OnClickEvent);
		BeautyModeBtn.setOnClickListener(OnClickEvent);
		mBtnStartBtn.setOnClickListener(OnClickEvent);
		View qrCode = findViewById(R.id.btnScan);
		qrCode.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, QRCodeScanActivity.class);
				startActivityForResult(intent, REQUEST_CODE);
			}
		});

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (data ==null || data.getExtras() == null || TextUtils.isEmpty(data.getExtras().getString("result"))) {
			return;
		}
		String result = data.getExtras().getString("result");
		if (mMediaEditURL != null) {
			mMediaEditURL.setText(result);
		}
	}
	
	//用于接收Service发送的消息
    public class MsgReceiver extends BroadcastReceiver{  
  
        @Override  
        public void onReceive(Context context, Intent intent) {  
 
            int value = intent.getIntExtra("LiveStreamingStopFinished", 0);   
            if(value == 1)//finished
            {
            	mBtnStartBtn.setEnabled(true);
            	mBtnStartBtn.setText("进入直播");
            }
            else//not yet finished
            {
            	mBtnStartBtn.setEnabled(false);
            	mBtnStartBtn.setText("直播停止中...");
            }
        }          
    } 
    
    @Override
	protected void onDestroy() {
        unregisterReceiver(msgReceiver);
		msgReceiver = null;
        super.onDestroy();
    }
}

